import React from "react";
import "../../styles/loader.styl";

const Loader = props => {
  return <div className="loader" />;
};

export default Loader;
