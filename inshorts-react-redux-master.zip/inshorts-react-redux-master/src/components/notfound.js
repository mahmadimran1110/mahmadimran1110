import React from "react";

const NotFound = (props) => {
    return (
        <div>header</div>
    )
}

export default NotFound;