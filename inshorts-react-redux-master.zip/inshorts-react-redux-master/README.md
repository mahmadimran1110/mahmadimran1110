# inshorts-react-redux

steps to run the project

    npm install
    npm run build